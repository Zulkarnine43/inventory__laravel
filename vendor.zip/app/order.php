<?php

namespace RainbowDigital;

use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    //
}
