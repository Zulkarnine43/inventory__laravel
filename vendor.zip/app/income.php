<?php

namespace RainbowDigital;

use Illuminate\Database\Eloquent\Model;

class income extends Model
{
    //
}
